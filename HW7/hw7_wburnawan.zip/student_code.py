# python imports
import os
from tqdm import tqdm

# torch imports
import torch
import torch.nn as nn
import torch.optim as optim

# helper functions for computer vision
import torchvision
import torchvision.transforms as transforms


class LeNet(nn.Module):
    def __init__(self, input_shape=(32, 32), num_classes=100):
        super(LeNet, self).__init__()
        # certain definitions
        self.conv1 = torch.nn.Conv2d(in_channels=3 ,out_channels=6, kernel_size=5, stride=1, padding=0, bias=True)
        self.relu = torch.nn.ReLU()
        self.max_pool_1 = torch.nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        self.conv2 = torch.nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5, stride=1, padding=0, bias=True)
        
        self.max_pool_2 = torch.nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        self.flatten = torch.nn.Flatten()
        self.linear1 = torch.nn.Linear(16*5*5,256, bias=True)
        
        self.linear2 = torch.nn.Linear(256,128, bias=True)
        
        self.linear3 = torch.nn.Linear(128,num_classes, bias=True)
        self.input_shape = input_shape

    def forward(self, x):
        shape_dict = {}
        # certain operations
        layer1 = self.conv1(x)
        layer1 = self.relu(layer1)
        layer1 = self.max_pool_1(layer1)
        layer2 = self.conv2(layer1)
        layer2 = self.relu(layer2)
        layer2 = self.max_pool_2(layer2)
        layer3 = self.flatten(layer2)
        layer4 = self.linear1(layer3)
        layer4 = self.relu(layer4)
        layer5 = self.linear2(layer4)
        layer5 = self.relu(layer5)
        out = self.linear3(layer5)
        list1 = []
        list2 = []
        list3 = []
        list4 = []
        list5 = []
        list6 = []
        for i in layer1.size():
            list1.append(i)
        for i in layer2.size():
            list2.append(i)
        for i in layer3.size():
            list3.append(i)
        for i in layer4.size():
            list4.append(i)
        for i in layer5.size():
            list5.append(i)
        for i in out.size():
            list6.append(i)
        shape_dict = {1:list1, 2:list2, 3:list3, 4:list4, 5:list5, 6:list6}
        return out, shape_dict


def count_model_params():
    '''
    return the number of trainable parameters of LeNet.
    '''
    model = LeNet()
    model_params = 0.0
    for name, param in model.named_parameters():
        temp = 1
        for i in param.size():
            temp *= i
        model_params += temp
    return model_params/(pow(10,6))


def train_model(model, train_loader, optimizer, criterion, epoch):
    """
    model (torch.nn.module): The model created to train
    train_loader (pytorch data loader): Training data loader
    optimizer (optimizer.*): A instance of some sort of optimizer, usually SGD
    criterion (nn.CrossEntropyLoss) : Loss function used to train the network
    epoch (int): Current epoch number
    """
    model.train()
    train_loss = 0.0
    for input, target in tqdm(train_loader, total=len(train_loader)):
        ###################################
        # fill in the standard training loop of forward pass,
        # backward pass, loss computation and optimizer step
        ###################################

        # 1) zero the parameter gradients
        optimizer.zero_grad()
        # 2) forward + backward + optimize
        output, _ = model(input)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()

        # Update the train_loss variable
        # .item() detaches the node from the computational graph
        # Uncomment the below line after you fill block 1 and 2
        train_loss += loss.item()

    train_loss /= len(train_loader)
    print('[Training set] Epoch: {:d}, Average loss: {:.4f}'.format(epoch+1, train_loss))

    return train_loss


def test_model(model, test_loader, epoch):
    model.eval()
    correct = 0
    with torch.no_grad():
        for input, target in test_loader:
            output, _ = model(input)
            pred = output.max(1, keepdim=True)[1]
            correct += pred.eq(target.view_as(pred)).sum().item()

    test_acc = correct / len(test_loader.dataset)
    print('[Test set] Epoch: {:d}, Accuracy: {:.2f}%\n'.format(
        epoch+1, 100. * test_acc))

    return test_acc

